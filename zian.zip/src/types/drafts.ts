export type DraftItem = {
    image: string;
    content: string;
    status: string;
    username: string;
    createDate: string;
    actions: string;
    photo: string;
}